Just Run RealScope.jar

Tested on MacOS, not sure if it will work on other platforms.
