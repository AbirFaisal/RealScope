package com.owon.uppersoft.vds.ui.resource;

public class ResourceCenter {
	public static final String ImageDirectory = "/com/owon/uppersoft/dso/image/";
	public static final String IMG_DIR = "/com/owon/uppersoft/dso/image/";

}
