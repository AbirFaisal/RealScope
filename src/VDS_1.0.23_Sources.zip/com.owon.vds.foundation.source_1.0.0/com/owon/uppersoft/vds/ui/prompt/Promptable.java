package com.owon.uppersoft.vds.ui.prompt;

import java.awt.Window;

public interface Promptable {
	Window getWindow();

	boolean isVisible();
}