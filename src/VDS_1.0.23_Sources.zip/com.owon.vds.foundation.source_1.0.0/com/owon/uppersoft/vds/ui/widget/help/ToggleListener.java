package com.owon.uppersoft.vds.ui.widget.help;

import java.awt.event.ActionEvent;

public interface ToggleListener {

	boolean toggle(ActionEvent e, boolean select);
}
