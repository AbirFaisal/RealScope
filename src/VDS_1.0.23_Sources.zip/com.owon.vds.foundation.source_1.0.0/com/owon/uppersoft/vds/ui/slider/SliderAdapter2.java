package com.owon.uppersoft.vds.ui.slider;

/**
 * 
 */
public class SliderAdapter2 implements SliderDelegate2 {

	// @Override
	// public void actionOff() {
	// }

	@Override
	public void onDispose() {
	}

	@Override
	public void onReset0() {
	}

	@Override
	public void valueIncret(int delta) {
	}

	// @Override
	// public void on50percent() {
	// }
}
