package com.owon.uppersoft.vds.ui.widget.custom;

import java.awt.Container;

import com.owon.uppersoft.vds.core.aspect.Localizable;

/**
 * LContainer，可设置语言的容器
 * 
 * @author Matt
 * 
 */
public abstract class LContainer extends Container implements Localizable {

}
