package com.owon.uppersoft.vds.ui.slider;

public abstract class SliderAdapter implements SliderDelegate {

	@Override
	public void actionOff() {
	}

	@Override
	public void on50percent() {
	}

	@Override
	public void onDispose() {
	}

	@Override
	public void valueChanged(int oldV, int newV) {
	}

}
