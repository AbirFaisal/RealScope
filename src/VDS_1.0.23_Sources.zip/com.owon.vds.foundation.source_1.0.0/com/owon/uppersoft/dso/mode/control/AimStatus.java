package com.owon.uppersoft.dso.mode.control;

/**
 * 三者的定义详见{@code AimStatusChecker}
 * 
 * @author John
 * 
 */
public enum AimStatus {
	Pass, Max, Min;
}
