package com.owon.uppersoft.dso.function;

public interface MarkableProvider {
	Markable get(int idx);
}