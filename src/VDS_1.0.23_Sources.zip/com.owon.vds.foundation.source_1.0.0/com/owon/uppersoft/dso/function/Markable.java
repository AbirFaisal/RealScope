package com.owon.uppersoft.dso.function;

public interface Markable {

	boolean isOn();

	int getVoltValue();

	int getPos0();

	String getName();
}