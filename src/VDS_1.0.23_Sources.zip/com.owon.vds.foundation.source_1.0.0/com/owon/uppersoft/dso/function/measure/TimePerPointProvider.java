package com.owon.uppersoft.dso.function.measure;

public interface TimePerPointProvider {
	double getTimePerPoint(int points);
}