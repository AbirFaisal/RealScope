package com.owon.uppersoft.dso.function.record;

import java.util.LinkedList;
import java.util.List;

import com.owon.uppersoft.vds.data.Point;

public class Timeline {
	public List<Point> timepoints = new LinkedList<Point>();
}