package com.owon.uppersoft.dso.model.trigger;

public interface TriggerInfoForChannel {
	boolean isChannelVideoTrg(int channel);
}