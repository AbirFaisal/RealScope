package com.owon.uppersoft.dso.model.trigger.common;

public interface IValueChange {
	void stateChanged(Object o);
}