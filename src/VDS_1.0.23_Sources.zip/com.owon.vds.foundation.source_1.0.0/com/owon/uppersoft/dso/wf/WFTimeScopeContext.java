package com.owon.uppersoft.dso.wf;

public interface WFTimeScopeContext {
	boolean isZoom();

	double getZoomGap();

	double getDiluteGap();
}