package com.owon.uppersoft.dso.model;

import com.owon.uppersoft.vds.core.wf.dm.DMDataInfo;

public class DMDataInfoTiny extends DMDataInfo {

}
