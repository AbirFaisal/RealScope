package com.owon.uppersoft.vds.device.interpret;


import com.owon.uppersoft.dso.source.comm.CProtocol;

public interface TinyCommunicationProtocol extends CProtocol {

	public static final int RESPONSE_LEN = 5;
	
//	public static final TinyCommAddress MACHINE_TYPE_ADD = TinyCommAddress.MACHINE_TYPE_ADD;
//	public static final TinyCommAddress FPGA_DOWNLOAD_QUERY_ADD = TinyCommAddress.FPGA_DOWNLOAD_QUERY_ADD;
//	public static final TinyCommAddress FPGA_DOWNLOAD_ADD = TinyCommAddress.FPGA_DOWNLOAD_ADD;
//	public static final TinyCommAddress GETDATA_ADD = TinyCommAddress.GETDATA_ADD;
//	public static final TinyCommAddress read_flash = TinyCommAddress.read_flash;
//	public static final TinyCommAddress write_flash = TinyCommAddress.write_flash;
	
}
