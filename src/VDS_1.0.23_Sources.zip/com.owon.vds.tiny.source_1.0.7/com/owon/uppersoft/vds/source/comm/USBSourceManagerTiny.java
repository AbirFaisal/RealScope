package com.owon.uppersoft.vds.source.comm;

import com.owon.uppersoft.dso.source.usb.USBPortsFilter;
import com.owon.uppersoft.dso.source.usb.USBSourceManager;

public class USBSourceManagerTiny extends USBSourceManager {

	public USBSourceManagerTiny(USBPortsFilter pf) {
		super(pf);
	}

}
