package com.owon.uppersoft.vds.source.front;

public final class TrgLocateInfo {
	public int htpTuneAdjustment;
	public int htpExtraAdjustment;
}