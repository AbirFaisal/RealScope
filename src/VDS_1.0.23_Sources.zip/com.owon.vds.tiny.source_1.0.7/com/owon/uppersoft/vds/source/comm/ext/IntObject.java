package com.owon.uppersoft.vds.source.comm.ext;

public class IntObject {

	public int value;
}
