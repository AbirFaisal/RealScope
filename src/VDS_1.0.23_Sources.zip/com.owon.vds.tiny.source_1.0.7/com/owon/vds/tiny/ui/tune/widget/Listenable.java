package com.owon.vds.tiny.ui.tune.widget;

public interface Listenable {

	boolean isListening();

}