package com.owon.vds.tiny.ui.tune.widget;

public interface IndexSelectable {

	void setSelectIndex(int idx);
}
